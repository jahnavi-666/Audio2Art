import torch
from diffusers import StableDiffusionPipeline
import matplotlib.pyplot as plt

def generate_image(pipe, prompt, output_path):
    params = {
        "num_inference_steps": 100,
        "width": 512,
        "height": 768,
        "num_images_per_prompt": 1,
        "negative_prompt": "ugly, distorted, low quality"
    }

    images = pipe(prompt, **params).images
    if images:
        images[0].save(output_path)
