const startBtn = document.getElementById("startBtn");
const output = document.getElementById("output");
const translatedOutput = document.getElementById("translatedOutput");
const generateBtn = document.getElementById("generateBtn");
const imageContainer = document.getElementById("imageContainer");
const languageSelect = document.getElementById("language");

window.SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();
recognition.continuous = false;
recognition.interimResults = false;
recognition.lang = languageSelect.value;

languageSelect.addEventListener("change", () => {
    recognition.lang = languageSelect.value;
});

startBtn.addEventListener("click", () => {
    recognition.start();
});

recognition.onresult = async (event) => {
    let transcript = event.results[0][0].transcript;
    output.innerText = transcript;

    // Translate to English
    const translatedText = await translateText(transcript);
    translatedOutput.innerText = translatedText;
};

recognition.onerror = (event) => {
    console.error("Speech recognition error:", event.error);
};

async function translateText(text) {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=en&dt=t&q=${encodeURIComponent(text)}`;

    try {
        const response = await fetch(url);
        const data = await response.json();
        return data[0].map(item => item[0]).join(" ");
    } catch (error) {
        console.error("Translation error:", error);
        return "Translation failed";
    }
}

// Send text to Flask and generate an image
generateBtn.addEventListener("click", async () => {
    const text = translatedOutput.innerText;

    if (!text) {
        alert("No text available for image generation.");
        return;
    }

    const response = await fetch("/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text })
    });

    const data = await response.json();

    if (data.image_url) {
        imageContainer.innerHTML = `<img src="${data.image_url}" alt="Generated Image">`;
    } else {
        alert("Image generation failed.");
    }
});
