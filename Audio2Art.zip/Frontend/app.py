from flask import Flask, render_template, request, jsonify
import os
from text_to_image import generate_image  # Your Stable Diffusion model function
import torch
from diffusers import StableDiffusionPipeline

app = Flask(__name__)

# Folder to store generated images
IMAGE_FOLDER = "static/generated_images"
os.makedirs(IMAGE_FOLDER, exist_ok=True)

# Load Stable Diffusion Model
model_id = "dreamlike-art/dreamlike-diffusion-1.0"
pipe = StableDiffusionPipeline.from_pretrained(model_id, torch_dtype=torch.float16, use_safetensors=True)
pipe = pipe.to("cuda")

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/faq')
def about():
    return render_template('faq.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route("/generate", methods=["POST"])
def generate():
    data = request.get_json()
    text = data.get("text", "")

    if not text:
        return jsonify({"error": "No text provided"}), 400

    # Generate an image using your model
    image_path = os.path.join(IMAGE_FOLDER, "output.png")
    generate_image(pipe, text, image_path)  

    return jsonify({"image_url": f"/{image_path}"})

if __name__ == "__main__":
    app.run(debug=True)
